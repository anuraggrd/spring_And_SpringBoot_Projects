package com.springboot.udemy.Exception;



@SuppressWarnings("serial")
public class CustomerNotFound extends RuntimeException {
	
	
	private String mesage ;
	
	public CustomerNotFound()
	{
		
	}

	public CustomerNotFound(String mesage) {
		super();
		this.mesage = mesage;
	}

	public String getMesage() {
		return mesage;
	}

	public void setMesage(String mesage) {
		this.mesage = mesage;
	}
	
	

}
