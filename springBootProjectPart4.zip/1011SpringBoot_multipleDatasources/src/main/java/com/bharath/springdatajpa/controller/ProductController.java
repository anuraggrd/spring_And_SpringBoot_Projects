package com.bharath.springdatajpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bharath.springdatajpa.product.entities.Product;
import com.bharath.springdatajpa.product.repos.ProductRepo;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductRepo repo;
	
	@RequestMapping(value="/addproduct", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public Product addCoupon(@RequestBody Product product)
	{
		Product saved = repo.save(product);
		return saved;
	}
	
	@RequestMapping(value="/getproducts", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Product> getAllCoupons()
	{
		List<Product> coupons = repo.findAll();
		return coupons;
	}

}
