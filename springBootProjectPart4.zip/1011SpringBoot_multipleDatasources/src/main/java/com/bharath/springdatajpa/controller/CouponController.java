package com.bharath.springdatajpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.bharath.springdatajpa.coupon.entities.Coupon;
import com.bharath.springdatajpa.coupon.repos.CouponRepo;

@RestController
@RequestMapping("/coupon")
public class CouponController {
	
	@Autowired
	private CouponRepo repo;
	
	@RequestMapping(value="/addcoupon", method = RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public Coupon addCoupon(@RequestBody Coupon coupon)
	{
		Coupon saved = repo.save(coupon);
		return saved;
	}
	
	@RequestMapping(value="/getcoupons", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Coupon> getAllCoupons()
	{
		List<Coupon> coupons = repo.findAll();
		return coupons;
	}

}
