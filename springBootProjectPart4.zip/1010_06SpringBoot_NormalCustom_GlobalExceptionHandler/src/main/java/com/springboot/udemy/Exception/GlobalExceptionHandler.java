package com.springboot.udemy.Exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
    @Value(value = "${data.exception.message1}")
    private String message1;
    @Value(value = "${data.exception.message2}")
    private String message2;
    @Value(value = "${data.exception.message3}")
    private String message3;
    
    @ExceptionHandler(value = CustomerAlreadyExists.class )
	public ResponseEntity<ErrorMessage> handleCustomerAlreadyFoundException(CustomerAlreadyExists customerAlreadyExists)
	{
    	
    	ErrorMessage errorMessage = new ErrorMessage(message1,customerAlreadyExists.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage,HttpStatus.CONFLICT);
	}
	
	@ExceptionHandler(value = CustomerNotFound.class )
	public ResponseEntity<ErrorMessage> handleCustomerNotFoundException(CustomerNotFound customerNotFound)
	{
		ErrorMessage errorMessage = new ErrorMessage(message2,customerNotFound.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = RuntimeException.class )
	public ResponseEntity<ErrorMessage> handleRuntimeException(RuntimeException runtimeException)
	{
		ErrorMessage errorMessage = new ErrorMessage(message3,runtimeException.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(value = Exception.class )
	public ResponseEntity<ErrorMessage> handleRuntimeException(Exception e)
	{
		System.out.println(e.getMessage()+"*********************************");
		ErrorMessage errorMessage = new ErrorMessage("Something went Wrong connect to Admin",e.getMessage());
		return new ResponseEntity<ErrorMessage>(errorMessage,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

class ErrorMessage
{
	private String message;
	private String details;

	public ErrorMessage() {

	}

	public ErrorMessage(String message, String details) {
		super();
		this.message = message;
		this.details = details;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
}