package com.jpq.udemy.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpq.udemy.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Long> {

}
