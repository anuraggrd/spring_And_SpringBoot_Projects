package com.accenture.lkm;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
	// this is the one way to off the banner
	//2nd way is put in the application.properties file
	public static void main(String[] args) {
		
		SpringApplication app = new SpringApplication(Application.class);
		//app.setBannerMode(Banner.Mode.OFF);
		
		
		app.run(args);
		//SpringApplication.run(Application.class, args);
	}

}
