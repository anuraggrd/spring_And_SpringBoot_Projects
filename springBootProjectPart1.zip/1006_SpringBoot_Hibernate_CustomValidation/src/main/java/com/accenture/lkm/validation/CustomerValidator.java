package com.accenture.lkm.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CustomerValidator implements ConstraintValidator<CustomerValidatorVal, String> {

	@Override
	public boolean isValid(String customerName, ConstraintValidatorContext arg1) {
		// TODO Auto-generated method stub
		boolean bol = true;
		if(customerName == null)
		{
			bol = false;
		}
		if(customerName.length() < 3)
		{
			bol = false;
		}
			
		
		return bol;
	}

}
