package com.jpq.caching;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

import com.jpq.caching.dao.CustomerRepo;
import com.jpq.caching.entity.Customer;

@SpringBootTest
class EhCacheJpaApplicationTests {

	@Autowired
	CustomerRepo repository;
	
	@Autowired
	EntityManager entityManager;
	
	@Test
	void contextLoads() {
	}

	@Test
	@Transactional
	public void testCaching()
	{
		Session session = entityManager.unwrap(Session.class);
		Customer customer = repository.findById(16L).get();
		session.evict(customer);
		repository.findById(16L).get();
	}
	
}
