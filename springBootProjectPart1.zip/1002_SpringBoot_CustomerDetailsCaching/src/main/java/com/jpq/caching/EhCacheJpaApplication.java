package com.jpq.caching;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EhCacheJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EhCacheJpaApplication.class, args);
	}

}
