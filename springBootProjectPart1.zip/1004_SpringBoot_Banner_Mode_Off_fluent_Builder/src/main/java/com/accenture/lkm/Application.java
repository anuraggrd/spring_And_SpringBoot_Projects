package com.accenture.lkm;

import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Application {
	// this is the 3rd way to off the banner
	public static void main(String[] args) {
		
		SpringApplicationBuilder app = new SpringApplicationBuilder()
		.sources(Application.class)
		.bannerMode(Banner.Mode.OFF);
		
		ConfigurableApplicationContext applicationContext = app.run(args);
		//SpringApplication.run(Application.class, args);
	}

}
