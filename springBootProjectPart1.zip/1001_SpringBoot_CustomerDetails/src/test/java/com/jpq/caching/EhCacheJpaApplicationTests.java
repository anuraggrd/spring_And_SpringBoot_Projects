package com.jpq.caching;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EhCacheJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
