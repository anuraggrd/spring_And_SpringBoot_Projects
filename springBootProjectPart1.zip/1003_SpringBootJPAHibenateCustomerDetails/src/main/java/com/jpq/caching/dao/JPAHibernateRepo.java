package com.jpq.caching.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.jpq.caching.entity.Customer;

@Repository
@Transactional
public class JPAHibernateRepo {
	
	@PersistenceContext
	EntityManager entity;
	
	public Customer findById(long id)
	{
		return entity.find(Customer.class, id);
	}
	
	public List<Customer> findAll()
	{
		TypedQuery<Customer> namedQuery = entity.createNamedQuery("get_All_customers", Customer.class);
		List<Customer> customers = namedQuery.getResultList();
		return customers;
	}
	
	
	public Customer save(Customer customer)
	{
		Customer customer2 = entity.merge(customer);
		return customer2;
	}
	
	public Customer update(Customer customer)
	{
		Customer customer2 = entity.merge(customer);
		return customer2;
	}
	

	public void deleteById(long id)
	{
		Customer customer = findById(id);
		entity.remove(customer);
		
	}
}
