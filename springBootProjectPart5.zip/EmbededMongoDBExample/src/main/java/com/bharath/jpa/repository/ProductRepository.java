package com.bharath.jpa.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.bharath.jpa.entity.Product;

public interface ProductRepository extends MongoRepository<Product,String> 
{

}
