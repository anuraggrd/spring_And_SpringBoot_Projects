package com.accenture.validation.entity;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

	@RequestMapping(value = "/create" , method =RequestMethod.POST,consumes = org.springframework.http.MediaType.APPLICATION_JSON_VALUE,produces = org.springframework.http.MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> customer( @Valid @RequestBody Customer customer , Errors err)
	{
		if(err.hasErrors())
		{
			return new ResponseEntity<String>(err.getAllErrors()+"", HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<String>( 1+"", HttpStatus.CREATED);
		
	}
	
}
