package com.accenture.validation.entity;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.accenture.validation.validation.CustomerValidatorVal;

public class Customer {
	
	@NotNull(message = "{NotEmpty.customer.name}")
	private long id;
	@CustomerValidatorVal(message = "{Customer.CustomerValidationValMessage}")
	@NotEmpty(message = "{NotNull.customer.id}")
	private String name;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String string) {
		this.name = string;
	}

	
}
