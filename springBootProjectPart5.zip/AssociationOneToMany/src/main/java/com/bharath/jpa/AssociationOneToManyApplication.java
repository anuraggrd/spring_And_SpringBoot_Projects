package com.bharath.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssociationOneToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssociationOneToManyApplication.class, args);
	}

}
