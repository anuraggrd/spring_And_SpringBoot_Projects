package com.bharath.jpa.oneToMany.entities;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	
	@OneToMany(mappedBy = "customer" , cascade = CascadeType.ALL)
	private Set<PhoneNumber>phnos;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String string) {
		this.name = string;
	}

	public Set<PhoneNumber> getPhnos() {
		return phnos;
	}

	public void setPhnos(Set<PhoneNumber> phnos) {
		this.phnos = phnos;
	}

}
