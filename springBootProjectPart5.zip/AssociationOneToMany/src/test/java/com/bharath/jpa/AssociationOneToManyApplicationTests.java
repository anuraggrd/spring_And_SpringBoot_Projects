package com.bharath.jpa;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.bharath.jpa.oneToMany.entities.Customer;
import com.bharath.jpa.oneToMany.entities.CustomerRepo;
import com.bharath.jpa.oneToMany.entities.PhoneNumber;

@SpringBootTest
class AssociationOneToManyApplicationTests {

	@Autowired
	private CustomerRepo repo;
	
	@Test
	void contextLoads() {
	}
	
	@Test
	public void savedetails()
	{
		Customer customer = new Customer();
		customer.setName("Rahul");
		HashSet<PhoneNumber> phnos = new HashSet<PhoneNumber>();
		PhoneNumber phoneNumber = new PhoneNumber();
		phoneNumber.setNumber("0123456789");
		phoneNumber.setType("Home");
		phoneNumber.setCustomer(customer);
		
		PhoneNumber phoneNumber2 = new PhoneNumber();
		phoneNumber2.setNumber("999739855482");
		phoneNumber2.setType("office");
		phoneNumber2.setCustomer(customer);
		
		phnos.add(phoneNumber);
		phnos.add(phoneNumber2);
		
		customer.setPhnos( phnos);
		repo.save(customer);
	}

	
	@Test
	@Transactional
	public void getDetails()
	{
		Customer customer = repo.findById(2l).get();
		System.out.println(customer.getName());
		
		  Set<PhoneNumber> phnos = customer.getPhnos(); phnos.forEach(phno ->
		  System.out.println(phno.getNumber()));
		 
	}
	
}
