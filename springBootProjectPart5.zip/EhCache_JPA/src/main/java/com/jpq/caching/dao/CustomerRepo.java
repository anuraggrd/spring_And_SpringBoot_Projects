package com.jpq.caching.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jpq.caching.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Long> {
	
	public Customer findByCustomerId(long id);

}
