package com.accenture.validation.entity;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class Customer {
	
	@NotNull(message = "Id is not null")
	private long id;
	@NotEmpty(message = "Customer Name is not null ")
	private String name;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String string) {
		this.name = string;
	}

	
}
