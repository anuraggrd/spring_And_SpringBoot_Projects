package com.accenture.com.service;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("Logging_Profile")
public class CustomerServiceProfileImpl {
	
	private static Logger logger =LoggerFactory.getLogger("CustomerServiceProfileImpl");
	
	static {
		
		logger.info("**************************************************************************");
		logger.info("Class Loading Custom Log[Class loaded : [CustomerServiceProfileImpl]");
		logger.info("**************************************************************************");
	}
	
	
}
