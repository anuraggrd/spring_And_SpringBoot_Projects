package com.embarkx.securitydefault.controler;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloContoller {
	@GetMapping("embarkx/hello")
	public String hello() {
		return "Hello";
	}

}
