logout http://localhost:8080/logout

http://localhost:8080/embarkx/hello
SpringBootWebSecurityConfiguration.class

http://localhost:8080/h2-console
jdbc url = jdbc:h2:mem:test
username =sa


git hub springsecurity
https://github.com/spring-projects/spring-security
and search user user.ddl