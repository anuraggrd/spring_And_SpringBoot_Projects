logout http://localhost:8080/logout

http://localhost:8080/embarkx/hello
SpringBootWebSecurityConfiguration.class