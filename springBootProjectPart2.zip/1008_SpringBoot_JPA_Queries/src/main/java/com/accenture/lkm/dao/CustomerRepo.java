package com.accenture.lkm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.accenture.lkm.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Long> {
	
	//Query Method Approach
	List<Customer> findBySalaryGreaterThanEqual(Double salary);
	List<Customer> findByNameAndSalaryGreaterThanEqual(String name,Double salary);
	List<Customer> findByOrderBySalaryDesc();
	
	//like
	List<Customer> findByNameContainingOrderBySalaryDesc(String pattern);
	List<Customer> findBySalaryGreaterThanEqualAndSalaryLessThanEqual(Double param1 , Double param2); 
	List<Customer> findByCustomerIdBetween(Long param1,Long param2);
	
	//@Query("select c from Customer c where c.salary >=?1")
	@Query("select c from Customer c where c.salary =?1")
	List<Customer> getAllCustomerBySalary(Double salary);
	
	@Query("select count(k),k.joiningDate from Customer k group by k.joiningDate")
	List getJoiningDateAndCountOfCustomer();
	
	@Query("select k from Customer k where k.salary>=:sal1 and k.salary =:sal2")
	List<Customer>getCustomersBySalary(@Param("sal1") Double sal1, @Param("sal2")Double sal2);
	
	@Query("UPDATE Customer c set c.name =?1 where c.customerId=?2")
	@Modifying
	Integer updateCustomerName(String customerName , Long customerId);
	
	
	
	

}
