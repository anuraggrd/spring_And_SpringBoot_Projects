package com.accenture.lkm.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.accenture.lkm.dto.CustomerModel;
import com.accenture.lkm.service.CustomerService;

@RestController
@RequestMapping("/customerDetailsapi")
public class CutomerController {

	@Autowired
	private CustomerService service;

	//add Customer
	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST , consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> addCustomer(@RequestBody CustomerModel customer)
	{
		CustomerModel customer2 = service.addCustomer(customer);
		System.out.println(customer2.getCustomerId());
		return new ResponseEntity<String>("Customer is added successfully with id :" + customer2.getCustomerId(),HttpStatus.CREATED);
	}


	//get All Customers 
	@RequestMapping(value = "/getCustDetails", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> getCustomerDetails()
	{
		Collection<CustomerModel> customerDetails = service.getCustomerDetails();

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}

	// get Customer By Id
	@RequestMapping(value = "/getCustById/{id}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomerModel> getCustomerById(@PathVariable("id")long id)
	{
		CustomerModel customer = service.getCustomerById(id);
		if(customer == null)
		{
			return new ResponseEntity<CustomerModel>(HttpStatus.NOT_FOUND);
		}else {

			return new ResponseEntity<CustomerModel>(customer,HttpStatus.OK);
		}

	}


	// update Cusomer

	@RequestMapping(value = "/updatecustomer", method = RequestMethod.PUT , consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CustomerModel> updateCustomer(@RequestBody CustomerModel customer)
	{
		CustomerModel updateCustomer = service.updateCustomer(customer);

		if(updateCustomer ==null)
		{
			return new ResponseEntity<CustomerModel>(HttpStatus.INTERNAL_SERVER_ERROR);
		}else
		{
			return new ResponseEntity<CustomerModel>(customer,HttpStatus.OK);
		}

	}
	// delete Customer
	@RequestMapping(value = "/deleteCustomerById/{id}", method = RequestMethod.DELETE,produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> deleteCustomerById(@PathVariable("id")long id)
	{
		CustomerModel customer = service.deleteCustomerById(id);
		if(customer == null)
		{
			return new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
		}else {

			return new ResponseEntity<String>("Remove Customer " +"{ CustomerId:"+ customer.getCustomerId() +" CustomerName: "+ customer.getName()+"}"  ,HttpStatus.OK);
		}
	}

	// 01
	@RequestMapping(value = "/getCustomergtrThanSalaryEqual/{salary}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> getCustomergtrThanSalaryEqual(@PathVariable("salary")double salary)
	{

		Collection<CustomerModel> customerDetails = service.getCustomergtrThanSalaryEqual(salary);

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}

	//02
	@RequestMapping(value = "/findByNameAndSalaryGreaterThanEqual/{name}/{salary}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> findByNameAndSalaryGreaterThanEqual(@PathVariable("name")String name,@PathVariable("salary")double salary)
	{

		Collection<CustomerModel> customerDetails = service.findByNameAndSalaryGreaterThanEqual(name,salary);

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}


	//03
	@RequestMapping(value = "/findByOrderBySalaryDesc", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> findByOrderBySalaryDesc()
	{

		Collection<CustomerModel> customerDetails = service.findByOrderBySalaryDesc();

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}

	//04
	@RequestMapping(value = "/findByNameContainingOrderBySalaryDesc/{pattern}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> findByNameContainingOrderBySalaryDesc(@PathVariable("pattern") String pattern)
	{

		Collection<CustomerModel> customerDetails = service.findByNameContainingOrderBySalaryDesc(pattern);

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}


	//05 
	@RequestMapping(value = "/findBySalaryGreaterThanEqualAndSalaryLessThanEqual/{sal1}/{sal2}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> findBySalaryGreaterThanEqualAndSalaryLessThanEqual(@PathVariable("sal1") double sal1,@PathVariable("sal2") double sal2)
	{

		Collection<CustomerModel> customerDetails = service.findBySalaryGreaterThanEqualAndSalaryLessThanEqual(sal1,sal2);

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}


	//06

	@RequestMapping(value = "/findByCustomerIdBetween/{id1}/{id2}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> findByCustomerIdBetween(@PathVariable("id1") long id1,@PathVariable("id2") long id2)
	{

		Collection<CustomerModel> customerDetails = service.findByCustomerIdBetween(id1,id2);

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}

	//07

	@RequestMapping(value = "/getAllCustomerBySalary/{salary}", method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection<CustomerModel>> getAllCustomerBySalary(@PathVariable("salary") double salary)
	{

		Collection<CustomerModel> customerDetails = service.getAllCustomerBySalary(salary);

		return new ResponseEntity<Collection<CustomerModel>>(customerDetails,HttpStatus.OK);
	}

	//08
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/getJoiningDateAndCountOfCustomer", method = RequestMethod.GET,produces =MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Collection> getJoiningDateAndCountOfCustomer()
	{

		List emplist = service.getJoiningDateAndCountOfCustomer();
		System.out.println(emplist);
		return new ResponseEntity<Collection>(emplist,HttpStatus.OK);


	}
	//09

	@RequestMapping(value = "/updateCustomerNameById/{name}/{id}", method = RequestMethod.PATCH,produces = MediaType.TEXT_HTML_VALUE)
	public ResponseEntity<String> updateCustomerNameById(@PathVariable("name")String name,@PathVariable("id")long id)
	{

		Integer i = service.updateCustomerNameById(name,id);
		if(i>=1)			return new ResponseEntity<String>("updateCustomerNameById :- ",HttpStatus.OK);
		else {

			return new ResponseEntity<String>("RecordNot Found :- ",HttpStatus.NOT_FOUND);
		}


	}



}
