package com.accenture.lkm.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.accenture.lkm.dao.CustomerRepo;
import com.accenture.lkm.dto.CustomerModel;
import com.accenture.lkm.entity.Customer;

@Service
@org.springframework.transaction.annotation.Transactional
public class CustomerService {

	@Autowired
	private CustomerRepo repo;

	// @Cacheput is used to put the item in the cache
	// or update the item already in the cache.
	// this method make sure that the return value from this method
	// is stored in the cache empSpaceCache with the employeeId as a key and
	// return value as the employee object return by the method after the DB update
	// note :- Hey is derived from the method's return value,
	// if return type of the method would have been int
	// then it would have format :result

	@CachePut(value = "empCacheSpace", key = "#result.customerId")
	public CustomerModel addCustomer(CustomerModel cusM) {
		Customer customerEntity = new Customer();
		BeanUtils.copyProperties(cusM, customerEntity);
		Customer cus = repo.save(customerEntity);

		CustomerModel customerModel = new CustomerModel();
		BeanUtils.copyProperties(cus, customerModel);

		System.out.println(customerModel);
		return customerModel;
	}

	// return value is saved in the cache with random key
	@Cacheable("empCacheSapce")
	public Collection<CustomerModel> getCustomerDetails() {
		List<Customer> customersEntity = repo.findAll();

		ArrayList<CustomerModel> list = new ArrayList<>();
		for (Customer customer : customersEntity) {
			CustomerModel cusModel = new CustomerModel();
			BeanUtils.copyProperties(customer, cusModel);
			list.add(cusModel);

		}
		return list;
	}

	// name element defines the name of the cache used
	// key defines the index value from for the cached object.
	// This annotation make sure that the return value from this method
	// is stored in the cache empCacheSpace with the employeeId as the key
	// and return value as the value.
	// Note : employee is retrieved from the parameter

	@Cacheable(value = "empCacheSpace", key = "#id", unless = "#result==null")
	public CustomerModel getCustomerById(long id) {
		CustomerModel customerModel = new CustomerModel();
		Customer customerEntity = repo.findById(id).get();
		BeanUtils.copyProperties(customerEntity, customerModel);
		return customerModel;

	}

	// @Cacheput is used to put the item in the cache
	// or update the item already in the cache.
	// this method make sure that the return value from this method
	// is stored in the cache empSpaceCache with the employeeId as a key and
	// return value as the employee object return by the method after the DB update
	// Note:- key is derived from the method parameter retrieved

	@CachePut(value = "empCacheSpace", key = "#cusM.customerId")
	public CustomerModel updateCustomer(CustomerModel cusM) {
		CustomerModel customerM = null;
		Customer customerEntity = repo.findById(cusM.getCustomerId()).get();
		if (customerEntity != null) {
			BeanUtils.copyProperties(cusM, customerEntity);
			Customer customerEntity2 = repo.save(customerEntity);

			customerM = new CustomerModel();
			BeanUtils.copyProperties(customerEntity2, customerM);
		}
		return customerM;

	}

	// this annotation is used to delete the value from the cache.
	// key define the index/key value for the cached object.
	// when delete method is successfully completed then element is removed from the
	// cache also
	// after removing the same from the DB.

	@CacheEvict(value = "empCacheSpace", key = "#id")
	public CustomerModel deleteCustomerById(long id) {
		CustomerModel customerM = null;
		Customer customerEntity = repo.findById(id).get();
		if (customerEntity != null) {
			repo.deleteById(id);

			customerM = new CustomerModel();
			BeanUtils.copyProperties(customerEntity, customerM);
		}

		return customerM;
	}

	// many Application need a method to clear the whole cache.
	// purge all the item in the cache

	@CacheEvict(value = "empCacheSpace", allEntries = true)
	public void evitAll() {

	}
	// when this method will be invoked then all the item in the cache will be
	// purged.

}
