package com.accenture.lkm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;

@SpringBootApplication
//step2: enable caching cache management support
@EnableCaching
public class Application {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
	//step 3: Cache manager implementation
	
	public CacheManager cacheManager()
	{
		ConcurrentMapCacheManager cache = new ConcurrentMapCacheManager("empCacheSpace");
		//empCacheSpace is the name of the cache
		//in production environment cache manager that is used is:
		//GuavaCache,EHCache and RedisCache
		
		return cache;
	}

}
