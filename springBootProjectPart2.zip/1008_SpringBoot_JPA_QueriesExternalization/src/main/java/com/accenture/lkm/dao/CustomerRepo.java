package com.accenture.lkm.dao;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.accenture.lkm.entity.Customer;

public interface CustomerRepo extends JpaRepository<Customer,Long> {
	
	
	
	//@Query("select c from Customer c where c.salary >=?1")
	@Query(name = "customerRepo.getAllCustomerByGreatorThanSalary")
	List<Customer> getAllCustomerByGreatorThanSalary(@Param("sal")Double salary);
	
	@Query(name = "customerRepo.getJoiningDateAndCountOfCustomer")
	List getJoiningDateAndCountOfCustomer();
	
	
	
	
	
	

}
